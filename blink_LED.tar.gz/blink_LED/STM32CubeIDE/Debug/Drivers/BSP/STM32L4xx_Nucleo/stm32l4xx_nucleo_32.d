Drivers/BSP/STM32L4xx_Nucleo/stm32l4xx_nucleo_32.o: \
 C:/Users/Alfonso\ Le\ Donne/Desktop/Programming/STM32/NUCLEO-L432KC/Workspaces/blink_LED/Drivers/BSP/STM32L4xx_Nucleo_32/stm32l4xx_nucleo_32.c \
 C:/Users/Alfonso\ Le\ Donne/Desktop/Programming/STM32/NUCLEO-L432KC/Workspaces/blink_LED/Drivers/BSP/STM32L4xx_Nucleo_32/stm32l4xx_nucleo_32.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal.h \
 ../../Core/Inc/stm32l4xx_hal_conf.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_def.h \
 ../../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l4xx.h \
 ../../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l432xx.h \
 ../../Drivers/CMSIS/Include/core_cm4.h \
 ../../Drivers/CMSIS/Include/cmsis_version.h \
 ../../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../../Drivers/CMSIS/Include/mpu_armv7.h \
 ../../Drivers/CMSIS/Device/ST/STM32L4xx/Include/system_stm32l4xx.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc_ex.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio_ex.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_dma.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_ll_dma.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_cortex.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_exti.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ex.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ramfunc.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr.h \
 ../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr_ex.h
C:/Users/Alfonso\ Le\ Donne/Desktop/Programming/STM32/NUCLEO-L432KC/Workspaces/blink_LED/Drivers/BSP/STM32L4xx_Nucleo_32/stm32l4xx_nucleo_32.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal.h:
../../Core/Inc/stm32l4xx_hal_conf.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_def.h:
../../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l4xx.h:
../../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l432xx.h:
../../Drivers/CMSIS/Include/core_cm4.h:
../../Drivers/CMSIS/Include/cmsis_version.h:
../../Drivers/CMSIS/Include/cmsis_compiler.h:
../../Drivers/CMSIS/Include/cmsis_gcc.h:
../../Drivers/CMSIS/Include/mpu_armv7.h:
../../Drivers/CMSIS/Device/ST/STM32L4xx/Include/system_stm32l4xx.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc_ex.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio_ex.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_dma.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_ll_dma.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_cortex.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_exti.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ex.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ramfunc.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr.h:
../../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr_ex.h:
